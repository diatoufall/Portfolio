/* src/components/Navbar.jsx */
import { useEffect, useState } from "react";
import { FaGithub, FaLinkedin, FaEnvelope } from "react-icons/fa";
import logo from "../assets/logo.jpg";

const navLinks = [
    { href: "#about", label: "À propos" },
    { href: "#skills", label: "Compétences" },
    { href: "#projects", label: "Projets" },
    { href: "#contact", label: "Contact" },
];

export default function Navbar() {
    const [scrolled, setScrolled] = useState(false);

    useEffect(() => {
        const onScroll = () => setScrolled(window.scrollY > 50);
        window.addEventListener("scroll", onScroll);
        return () => window.removeEventListener("scroll", onScroll);
    }, []);

    return (
        <nav
            style={{
                position: "fixed",
                top: 0, left: 0, right: 0,
                zIndex: 100,
                padding: scrolled ? "12px 40px" : "20px 40px",
                background: scrolled ? "rgba(15,20,50,0.92)" : "transparent",
                backdropFilter: scrolled ? "blur(16px)" : "none",
                borderBottom: scrolled ? "1px solid rgba(255,255,255,0.06)" : "none",
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                transition: "all 0.35s ease",
            }}
        >
            {/* LOGO */}
            <a href="/" style={{ display: "flex", alignItems: "center", gap: 12, textDecoration: "none" }}>
                <img
                    src={logo}
                    alt="Mourad"
                    style={{
                        height: 74,
                        width: 74,
                        borderRadius: "9999px",
                        objectFit: "cover",
                        border: "2px solid rgba(99,102,241,0.6)",
                        boxShadow: "0 0 16px rgba(99,102,241,0.3)",
                        transition: "transform 0.3s, box-shadow 0.3s",
                    }}
                    onMouseEnter={e => {
                        e.currentTarget.style.transform = "scale(1.1)";
                        e.currentTarget.style.boxShadow = "0 0 24px rgba(99,102,241,0.6)";
                    }}
                    onMouseLeave={e => {
                        e.currentTarget.style.transform = "scale(1)";
                        e.currentTarget.style.boxShadow = "0 0 16px rgba(99,102,241,0.3)";
                    }}
                />
                <span style={{
                    fontSize: 18, fontWeight: 700, letterSpacing: -0.5,
                    background: "linear-gradient(135deg, #6366f1, #a78bfa)",
                    WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
                }}>
                    Mourad
                </span>
            </a>

            {/* LINKS + SOCIAL */}
            <div style={{ display: "flex", alignItems: "center", gap: 36 }}>
                {navLinks.map(link => (
                    <a
                        key={link.href}
                        href={link.href}
                        style={{
                            color: "rgba(255,255,255,0.65)",
                            fontSize: 14, fontWeight: 500,
                            textDecoration: "none", letterSpacing: 0.5,
                            transition: "color 0.2s",
                        }}
                        onMouseEnter={e => e.currentTarget.style.color = "#fff"}
                        onMouseLeave={e => e.currentTarget.style.color = "rgba(255,255,255,0.65)"}
                    >
                        {link.label}
                    </a>
                ))}

                {/* Social icons — on évite la déstructuration pour contourner ESLint */}
                <div style={{
                    display: "flex", gap: 16, marginLeft: 8,
                    borderLeft: "1px solid rgba(255,255,255,0.12)",
                    paddingLeft: 20,
                }}>
                    <a href="https://github.com/yourusername" target="_blank" rel="noopener noreferrer"
                       style={{ color: "rgba(255,255,255,0.5)", fontSize: 20, transition: "color 0.2s" }}
                       onMouseEnter={e => e.currentTarget.style.color = "#a5b4fc"}
                       onMouseLeave={e => e.currentTarget.style.color = "rgba(255,255,255,0.5)"}
                    >
                        <FaGithub />
                    </a>
                    <a href="https://linkedin.com/in/yourusername" target="_blank" rel="noopener noreferrer"
                       style={{ color: "rgba(255,255,255,0.5)", fontSize: 20, transition: "color 0.2s" }}
                       onMouseEnter={e => e.currentTarget.style.color = "#a5b4fc"}
                       onMouseLeave={e => e.currentTarget.style.color = "rgba(255,255,255,0.5)"}
                    >
                        <FaLinkedin />
                    </a>
                    <a href="mailto:your@email.com"
                       style={{ color: "rgba(255,255,255,0.5)", fontSize: 20, transition: "color 0.2s" }}
                       onMouseEnter={e => e.currentTarget.style.color = "#a5b4fc"}
                       onMouseLeave={e => e.currentTarget.style.color = "rgba(255,255,255,0.5)"}
                    >
                        <FaEnvelope />
                    </a>
                </div>
            </div>
        </nav>
    );
}
