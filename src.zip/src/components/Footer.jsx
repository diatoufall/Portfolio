import { FaGithub, FaLinkedin, FaTwitter } from 'react-icons/fa';

export default function Footer() {
    return (
        <footer style={{
            background: '#060b18',
            borderTop: '1px solid rgba(255,255,255,0.06)',
            padding: '48px 40px',
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            flexWrap: 'wrap', gap: 24,
        }}>
            <span style={{
                fontSize: 18, fontWeight: 800, letterSpacing: -0.5,
                background: 'linear-gradient(135deg, #6366f1, #a78bfa)',
                WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
            }}>
                Mourad.
            </span>

            <p style={{ color: '#475569', fontSize: 14 }}>
                © 2025 Mourad — Tous droits réservés.
            </p>

            <div style={{ display: 'flex', gap: 20 }}>
                {[
                    { Icon: FaGithub, href: 'https://github.com/yourusername' },
                    { Icon: FaLinkedin, href: 'https://linkedin.com/in/yourusername' },
                    { Icon: FaTwitter, href: 'https://twitter.com/yourusername' },
                ].map(({ Icon, href }) => (
                    <a key={href} href={href} target="_blank" rel="noopener noreferrer"
                       style={{ color: '#475569', fontSize: 18, transition: 'color 0.2s' }}
                       onMouseEnter={e => e.currentTarget.style.color = '#a5b4fc'}
                       onMouseLeave={e => e.currentTarget.style.color = '#475569'}
                    >
                        <Icon />
                    </a>
                ))}
            </div>
        </footer>
    );
}
