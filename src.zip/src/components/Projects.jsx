import { motion } from 'framer-motion';
import { FaGithub, FaExternalLinkAlt } from 'react-icons/fa';

const projects = [
    {
        id: 1,
        title: 'E-Commerce Platform',
        description: 'Plateforme e-commerce complète avec panier, paiement Stripe et panneau admin.',
        tags: ['React', 'Node.js', 'MongoDB', 'Stripe'],
        github: 'https://github.com/yourusername/ecommerce',
        live: 'https://ecommerce-demo.com',
        color: 'linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%)',
    },
    {
        id: 2,
        title: 'Task Management App',
        description: 'Application de gestion de tâches avec authentification et collaboration en temps réel.',
        tags: ['React', 'Firebase', 'Tailwind CSS'],
        github: 'https://github.com/yourusername/taskapp',
        live: 'https://taskapp-demo.com',
        color: 'linear-gradient(135deg, #0ea5e9 0%, #6366f1 100%)',
    },
    {
        id: 3,
        title: 'Blog Platform',
        description: 'Plateforme de blog avec système de commentaires, recherche avancée et SEO optimisé.',
        tags: ['Next.js', 'PostgreSQL', 'GraphQL'],
        github: 'https://github.com/yourusername/blog',
        live: 'https://blog-demo.com',
        color: 'linear-gradient(135deg, #f59e0b 0%, #ef4444 100%)',
    },
];

export default function Projects() {
    return (
        <section id="projects" style={{ background: '#0f172a', padding: '120px 40px' }}>
            <div style={{ maxWidth: 1100, margin: '0 auto' }}>

                <motion.p
                    style={{ color: '#6366f1', fontSize: 12, fontWeight: 700, letterSpacing: 4, textTransform: 'uppercase', marginBottom: 16 }}
                    initial={{ opacity: 0 }} whileInView={{ opacity: 1 }}
                >
                    Projets
                </motion.p>

                <motion.h2
                    style={{
                        fontSize: 'clamp(2rem, 4vw, 3rem)', fontWeight: 800,
                        color: '#f1f5f9', marginBottom: 72, letterSpacing: -1,
                    }}
                    initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }}
                >
                    Ce que j'ai construit
                </motion.h2>

                <div style={{ display: 'flex', flexDirection: 'column', gap: 32 }}>
                    {projects.map((project, index) => (
                        <motion.div
                            key={project.id}
                            style={{
                                display: 'grid',
                                gridTemplateColumns: '280px 1fr',
                                gap: 0,
                                background: 'rgba(255,255,255,0.03)',
                                border: '1px solid rgba(255,255,255,0.07)',
                                borderRadius: 20, overflow: 'hidden',
                            }}
                            initial={{ opacity: 0, y: 30 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            transition={{ delay: index * 0.1, duration: 0.6 }}
                            whileHover={{ borderColor: 'rgba(99,102,241,0.35)' }}
                        >
                            {/* Color block */}
                            <div style={{
                                background: project.color,
                                display: 'flex', alignItems: 'center', justifyContent: 'center',
                                fontSize: 40, fontWeight: 800, color: 'rgba(255,255,255,0.3)',
                                letterSpacing: -2,
                            }}>
                                0{project.id}
                            </div>

                            {/* Content */}
                            <div style={{ padding: '36px 40px' }}>
                                <h3 style={{ color: '#f1f5f9', fontSize: 22, fontWeight: 700, marginBottom: 12, letterSpacing: -0.5 }}>
                                    {project.title}
                                </h3>
                                <p style={{ color: '#94a3b8', fontSize: 15, lineHeight: 1.7, marginBottom: 24 }}>
                                    {project.description}
                                </p>

                                {/* Tags */}
                                <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 28 }}>
                                    {project.tags.map(tag => (
                                        <span key={tag} style={{
                                            background: 'rgba(99,102,241,0.12)',
                                            border: '1px solid rgba(99,102,241,0.25)',
                                            color: '#a5b4fc', fontSize: 12, fontWeight: 500,
                                            padding: '4px 12px', borderRadius: 50,
                                        }}>
                                            {tag}
                                        </span>
                                    ))}
                                </div>

                                {/* Links */}
                                <div style={{ display: 'flex', gap: 20 }}>
                                    <a href={project.github} target="_blank" rel="noopener noreferrer"
                                       style={{ display: 'flex', alignItems: 'center', gap: 7, color: '#94a3b8', fontSize: 14, textDecoration: 'none', transition: 'color 0.2s' }}
                                       onMouseEnter={e => e.currentTarget.style.color = '#fff'}
                                       onMouseLeave={e => e.currentTarget.style.color = '#94a3b8'}
                                    >
                                        <FaGithub /> Code source
                                    </a>
                                    <a href={project.live} target="_blank" rel="noopener noreferrer"
                                       style={{ display: 'flex', alignItems: 'center', gap: 7, color: '#94a3b8', fontSize: 14, textDecoration: 'none', transition: 'color 0.2s' }}
                                       onMouseEnter={e => e.currentTarget.style.color = '#6366f1'}
                                       onMouseLeave={e => e.currentTarget.style.color = '#94a3b8'}
                                    >
                                        <FaExternalLinkAlt /> Voir le projet
                                    </a>
                                </div>
                            </div>
                        </motion.div>
                    ))}
                </div>
            </div>
        </section>
    );
}
