import { motion } from 'framer-motion';

const skills = [
    { name: 'React', level: 'Avancé' },
    { name: 'JavaScript', level: 'Avancé' },
    { name: 'Node.js', level: 'Avancé' },
    { name: 'MongoDB', level: 'Intermédiaire' },
    { name: 'Tailwind CSS', level: 'Avancé' },
    { name: 'Git', level: 'Avancé' },
];

export default function Skills() {
    return (
        <section
            id="skills"
            className="py-20 px-5 bg-gradient-to-br from-indigo-500 to-purple-600 max-w-6xl mx-auto"
        >
            {/* Title */}
            <motion.h2
                className="text-4xl font-bold text-white text-center mb-12"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                transition={{ duration: 0.8 }}
            >
                Mes Compétences
            </motion.h2>

            {/* Skills Grid */}
            <motion.div
                className="grid gap-6 sm:grid-cols-2 md:grid-cols-3"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                transition={{ duration: 0.8 }}
            >
                {skills.map((skill, index) => (
                    <motion.div
                        key={index}
                        className="bg-white/10 p-6 rounded-xl text-center backdrop-blur-md border border-white/20 hover:bg-white/20 hover:-translate-y-1 transition-all"
                        whileHover={{ scale: 1.05 }}
                        transition={{ type: 'spring', stiffness: 300 }}
                    >
                        <h3 className="text-white text-xl font-semibold mb-2">{skill.name}</h3>
                        <p className="text-white/80 text-sm">{skill.level}</p>
                    </motion.div>
                ))}
            </motion.div>
        </section>
    );
}
