import { motion } from 'framer-motion';
import { useState } from 'react';
import { FaEnvelope, FaPhone, FaMapMarkerAlt } from 'react-icons/fa';

export default function Contact() {
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        message: '',
    });

    const [submitted, setSubmitted] = useState(false);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prev) => ({ ...prev, [name]: value }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log('Form submitted:', formData);

        setSubmitted(true);
        setTimeout(() => {
            setFormData({ name: '', email: '', message: '' });
            setSubmitted(false);
        }, 3000);
    };

    return (
        <section
            id="contact"
            className="py-20 px-5 bg-gradient-to-br from-indigo-500 to-purple-600 max-w-6xl mx-auto"
        >
            {/* Title */}
            <motion.h2
                className="text-4xl font-bold text-white text-center mb-12"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                transition={{ duration: 0.8 }}
            >
                Restons en Contact
            </motion.h2>

            {/* Container */}
            <motion.div
                className="grid md:grid-cols-2 gap-12"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
            >
                {/* Info Box */}
                <div className="flex flex-col gap-8 text-white">
                    <div className="flex items-start gap-4">
                        <FaEnvelope className="text-2xl mt-1" />
                        <div>
                            <h3 className="text-lg font-semibold mb-1">Email</h3>
                            <p className="opacity-90">your@email.com</p>
                        </div>
                    </div>

                    <div className="flex items-start gap-4">
                        <FaPhone className="text-2xl mt-1" />
                        <div>
                            <h3 className="text-lg font-semibold mb-1">Téléphone</h3>
                            <p className="opacity-90">514 3333333</p>
                        </div>
                    </div>

                    <div className="flex items-start gap-4">
                        <FaMapMarkerAlt className="text-2xl mt-1" />
                        <div>
                            <h3 className="text-lg font-semibold mb-1">Localisation</h3>
                            <p className="opacity-90">Paris, France</p>
                        </div>
                    </div>
                </div>

                {/* Form */}
                <form onSubmit={handleSubmit} className="flex flex-col gap-6">
                    <input
                        type="text"
                        placeholder="Votre nom"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        required
                        className="p-4 rounded-lg text-gray-800 focus:outline-none focus:ring-2 focus:ring-white"
                    />

                    <input
                        type="email"
                        placeholder="Votre email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                        className="p-4 rounded-lg text-gray-800 focus:outline-none focus:ring-2 focus:ring-white"
                    />

                    <textarea
                        placeholder="Votre message"
                        name="message"
                        value={formData.message}
                        onChange={handleChange}
                        required
                        className="p-4 rounded-lg text-gray-800 min-h-[120px] resize-none focus:outline-none focus:ring-2 focus:ring-white"
                    />

                    <motion.button
                        type="submit"
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        className="bg-white text-indigo-600 font-semibold py-4 rounded-lg transition disabled:opacity-60"
                    >
                        {submitted ? '✓ Message envoyé !' : 'Envoyer'}
                    </motion.button>
                </form>
            </motion.div>
        </section>
    );
}
