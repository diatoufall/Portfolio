import { FaGithub, FaLinkedin, FaTwitter } from 'react-icons/fa';

export default function Footer() {
    return (
        <footer className="bg-black/20 text-white text-center py-8 mt-12">
            {/* Social Links */}
            <div className="flex justify-center gap-8 mb-4">
                <a
                    href="https://github.com/yourusername"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-2xl hover:text-indigo-500 hover:-translate-y-1 transition-all"
                >
                    <FaGithub />
                </a>
                <a
                    href="https://linkedin.com/in/yourusername"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-2xl hover:text-indigo-500 hover:-translate-y-1 transition-all"
                >
                    <FaLinkedin />
                </a>
                <a
                    href="https://twitter.com/yourusername"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-2xl hover:text-indigo-500 hover:-translate-y-1 transition-all"
                >
                    <FaTwitter />
                </a>
            </div>

            {/* Text */}
            <p className="opacity-90 mb-1">© 2024 Mourad. Tous droits réservés.</p>
            <p className="opacity-90">Fait avec ❤️ en React</p>
        </footer>
    );
}
