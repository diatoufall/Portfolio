import { motion } from 'framer-motion';
import { FaArrowDown } from 'react-icons/fa';

export default function Hero() {
    return (
        <section
            id="hero"
            className="relative flex flex-col justify-center items-center h-screen text-center text-white px-6 bg-gradient-to-br from-indigo-500 to-purple-600"
        >
            {/* Title */}
            <motion.h1
                className="text-5xl md:text-6xl font-extrabold mb-4"
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
            >
                Salut, je suis Mourad 👋
            </motion.h1>

            {/* Subtitle */}
            <motion.p
                className="text-xl md:text-2xl font-light text-white/90 mb-8"
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.2 }}
            >
                Développeur Full Stack | Créateur de solutions web modernes
            </motion.p>

            {/* Call To Action */}
            <motion.button
                className="px-8 py-3 text-lg md:text-xl font-semibold rounded-full bg-white text-indigo-600 hover:scale-105 hover:shadow-xl transition-transform duration-300"
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.4 }}
                onClick={() =>
                    document
                        .getElementById('contact')
                        .scrollIntoView({ behavior: 'smooth' })
                }
            >
                Parlons ensemble
            </motion.button>

            {/* Animated Arrow */}
            <motion.div
                className="absolute bottom-8 text-2xl md:text-3xl"
                animate={{ y: [0, 10, 0] }}
                transition={{ repeat: Infinity, duration: 2 }}
            >
                <FaArrowDown />
            </motion.div>
        </section>
    );
}
