import { motion } from 'framer-motion';

export default function About() {
    return (
        <section id="about" className="py-20 px-5 max-w-6xl mx-auto">
            <motion.h2
                className="text-4xl font-bold text-center mb-12 text-gray-800"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                transition={{ duration: 0.8 }}
            >
                À Propos de Moi
            </motion.h2>

            <motion.div
                className="grid gap-8 md:grid-cols-2 items-center"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
            >
                <div>
                    <p className="mb-4 text-gray-600 leading-relaxed">
                        Je suis un développeur passionné avec 5 ans d'expérience dans la création d'applications web modernes et performantes.
                    </p>
                    <p className="mb-4 text-gray-600 leading-relaxed">
                        J'aime transformer des idées en solutions réelles, en utilisant les dernières technologies et en mettant l'accent sur l'expérience utilisateur.
                    </p>
                    <p className="text-gray-600 leading-relaxed">
                        Quand je ne code pas, je contribue à l'open source et j'apprends de nouvelles technologies.
                    </p>
                </div>

                <div className="w-full h-72 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg flex items-center justify-center text-white text-lg">
                    [Votre photo/illustration ici]
                </div>
            </motion.div>
        </section>
    );
}
