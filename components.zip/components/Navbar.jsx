import { FaGithub, FaLinkedin, FaEnvelope } from 'react-icons/fa';

export default function Navbar() {
    return (
        <nav className="flex justify-between items-center py-6 px-5 md:px-20 bg-black/10 backdrop-blur-md sticky top-0 z-50">
            {/* Logo */}
            <h1 className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-indigo-500 to-purple-600 bg-clip-text text-transparent">
                Mourad
            </h1>

            {/* Links */}
            <div className="flex items-center gap-6 md:gap-8">
                <a href="#about" className="text-white font-medium hover:text-indigo-500 transition-colors">
                    À propos
                </a>
                <a href="#skills" className="text-white font-medium hover:text-indigo-500 transition-colors">
                    Compétences
                </a>
                <a href="#projects" className="text-white font-medium hover:text-indigo-500 transition-colors">
                    Projets
                </a>
                <a href="#contact" className="text-white font-medium hover:text-indigo-500 transition-colors">
                    Contact
                </a>

                {/* Social Icons */}
                <div className="flex gap-4 md:gap-6 ml-4">
                    <a
                        href="https://github.com/yourusername"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-white text-lg hover:text-indigo-500 hover:-translate-y-1 transition-all"
                    >
                        <FaGithub />
                    </a>
                    <a
                        href="https://linkedin.com/in/yourusername"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-white text-lg hover:text-indigo-500 hover:-translate-y-1 transition-all"
                    >
                        <FaLinkedin />
                    </a>
                    <a
                        href="mailto:your@email.com"
                        className="text-white text-lg hover:text-indigo-500 hover:-translate-y-1 transition-all"
                    >
                        <FaEnvelope />
                    </a>
                </div>
            </div>
        </nav>
    );
}
