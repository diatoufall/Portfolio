import { motion } from 'framer-motion';
import { FaGithub, FaExternalLinkAlt } from 'react-icons/fa';

const projects = [
    {
        id: 1,
        title: 'E-Commerce Platform',
        description:
            'Plateforme e-commerce complète avec panier, paiement Stripe et admin panel.',
        tags: ['React', 'Node.js', 'MongoDB', 'Stripe'],
        github: 'https://github.com/yourusername/ecommerce',
        live: 'https://ecommerce-demo.com',
    },
    {
        id: 2,
        title: 'Task Management App',
        description:
            'Application de gestion de tâches avec authentification et partage en temps réel.',
        tags: ['React', 'Firebase', 'Tailwind CSS'],
        github: 'https://github.com/yourusername/taskapp',
        live: 'https://taskapp-demo.com',
    },
    {
        id: 3,
        title: 'Blog Platform',
        description:
            'Plateforme de blog avec système de commentaires et recherche avancée.',
        tags: ['Next.js', 'PostgreSQL', 'GraphQL'],
        github: 'https://github.com/yourusername/blog',
        live: 'https://blog-demo.com',
    },
];

export default function Projects() {
    return (
        <section
            id="projects"
            className="py-20 px-5 bg-white max-w-6xl mx-auto"
        >
            {/* Title */}
            <motion.h2
                className="text-4xl font-bold text-gray-800 text-center mb-12"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                transition={{ duration: 0.8 }}
            >
                Mes Projets
            </motion.h2>

            {/* Grid */}
            <motion.div
                className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                transition={{ duration: 0.8 }}
            >
                {projects.map((project, index) => (
                    <motion.div
                        key={project.id}
                        className="bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transition transform hover:-translate-y-2"
                        whileHover={{ scale: 1.03 }}
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.1 }}
                    >
                        {/* Image Placeholder */}
                        <div className="h-48 bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white font-semibold">
                            Projet {project.id}
                        </div>

                        {/* Content */}
                        <div className="p-6">
                            <h3 className="text-xl font-semibold text-gray-800 mb-2">
                                {project.title}
                            </h3>

                            <p className="text-gray-600 mb-4 text-sm leading-relaxed">
                                {project.description}
                            </p>

                            {/* Tags */}
                            <div className="flex flex-wrap gap-2 mb-4">
                                {project.tags.map((tag, i) => (
                                    <span
                                        key={i}
                                        className="bg-indigo-500 text-white text-xs px-3 py-1 rounded-full"
                                    >
                    {tag}
                  </span>
                                ))}
                            </div>

                            {/* Links */}
                            <div className="flex gap-4">
                                <a
                                    href={project.github}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="flex items-center gap-2 text-indigo-600 font-semibold hover:text-purple-600 transition"
                                >
                                    <FaGithub /> Code
                                </a>

                                <a
                                    href={project.live}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="flex items-center gap-2 text-indigo-600 font-semibold hover:text-purple-600 transition"
                                >
                                    <FaExternalLinkAlt /> Voir
                                </a>
                            </div>
                        </div>
                    </motion.div>
                ))}
            </motion.div>
        </section>
    );
}
